/* ================================
   DEVENDRA SINGH PORTFOLIO
   JAVASCRIPT
================================ */


/* ================================
   MOBILE MENU
================================ */

const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

if (menuBtn && navLinks) {

  menuBtn.addEventListener("click", () => {
    navLinks.classList.toggle("active");
  });

}


/* Close mobile menu after clicking a link */

document.querySelectorAll("#navLinks a").forEach((link) => {

  link.addEventListener("click", () => {

    if (navLinks) {
      navLinks.classList.remove("active");
    }

  });

});


/* ================================
   SCROLL REVEAL
================================ */

const revealElements = document.querySelectorAll(".reveal");

const revealObserver = new IntersectionObserver(
  (entries) => {

    entries.forEach((entry) => {

      if (entry.isIntersecting) {

        entry.target.classList.add("show");

        revealObserver.unobserve(entry.target);

      }

    });

  },
  {
    threshold: 0.12
  }
);


revealElements.forEach((element) => {

  revealObserver.observe(element);

});


/* ================================
   ACTIVE NAVIGATION
================================ */

const sections = document.querySelectorAll("main section[id]");
const navItems = document.querySelectorAll("#navLinks a");

const activeObserver = new IntersectionObserver(
  (entries) => {

    entries.forEach((entry) => {

      if (entry.isIntersecting) {

        navItems.forEach((link) => {

          link.classList.toggle(
            "active",
            link.getAttribute("href") === `#${entry.target.id}`
          );

        });

      }

    });

  },
  {
    rootMargin: "-35% 0px -55% 0px"
  }
);


sections.forEach((section) => {

  activeObserver.observe(section);

});


/* ================================
   CERTIFICATE MODAL
================================ */

const certModal = document.getElementById("certModal");
const modalImage = document.getElementById("modalImage");
const modalTitle = document.getElementById("modalTitle");
const modalClose = document.getElementById("modalClose");


document.querySelectorAll(".cert-image[data-image]").forEach((button) => {

  button.addEventListener("click", () => {

    if (!certModal || !modalImage || !modalTitle) {
      return;
    }

    modalImage.src = button.dataset.image;

    modalImage.alt = button.dataset.title || "Certificate";

    modalTitle.textContent = button.dataset.title || "Certificate";

    certModal.classList.add("active");

    certModal.setAttribute("aria-hidden", "false");

    document.body.style.overflow = "hidden";

  });

});


/* Close certificate modal */

function closeModal() {

  if (!certModal || !modalImage) {
    return;
  }

  certModal.classList.remove("active");

  certModal.setAttribute("aria-hidden", "true");

  modalImage.src = "";

  document.body.style.overflow = "";

}


/* Close button */

if (modalClose) {

  modalClose.addEventListener("click", closeModal);

}


/* Close when clicking outside image */

if (certModal) {

  certModal.addEventListener("click", (event) => {

    if (event.target === certModal) {

      closeModal();

    }

  });

}


/* Close with Escape key */

document.addEventListener("keydown", (event) => {

  if (event.key === "Escape") {

    closeModal();

  }

});


/* ================================
   BACK TO TOP BUTTON
================================ */

const topBtn = document.getElementById("topBtn");


window.addEventListener("scroll", () => {

  if (!topBtn) {
    return;
  }

  if (window.scrollY > 500) {

    topBtn.classList.add("show");

  } else {

    topBtn.classList.remove("show");

  }

});


if (topBtn) {

  topBtn.addEventListener("click", () => {

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });

  });

}


/* ================================
   CURRENT YEAR
================================ */

const yearElement = document.getElementById("year");

if (yearElement) {

  yearElement.textContent = new Date().getFullYear();

}